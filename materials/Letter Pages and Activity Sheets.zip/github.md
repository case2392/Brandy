# GitHub source

repo: case2392/Brandy
branch: claude/brandy-homeschool-planning-o7nqii
path: materials

## Last sync
date: 2026-08-05T02:00:24Z

### Updated in this project
- Read `materials/scripts/generate_printables.py` (full current design source for all 4 PDFs)
- Read `README.md` + `materials/README.md` for context
- Redesigning all four printables as print-ready pages (Organic system, Andika tracing font)

## Screen map
| Project screen | Repo source |
|---|---|
| Letter Pages — Big Kid.dc.html | materials/scripts/generate_printables.py (big_kid_page) |
| Letter Pages — Toddler.dc.html | materials/scripts/generate_printables.py (toddler_page) |
| Weekly Rhythm Chart.dc.html | materials/scripts/generate_printables.py (rhythm_chart) |
| Bible Story Sheets.dc.html | materials/scripts/generate_printables.py (bible_sheets) |
