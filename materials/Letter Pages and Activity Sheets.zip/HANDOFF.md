# Redesigned printables — handoff

Redesign of the four printables from `case2392/Brandy` (branch `claude/brandy-homeschool-planning-o7nqii`, `materials/scripts/generate_printables.py`).

## Files
- `Letter Pages - Big Kid.dc.html` — 26 pages, A–Z. Andika tracing glyphs on 3-line guides, sage start dots, scattered letter-hunt scene, draw box.
- `Letter Pages - Toddler.dc.html` — 26 pages. Giant hollow letter, corner lowercase, 3-up crayon trace row. Rose accent.
- `Weekly Rhythm Chart.dc.html` — 1 landscape page. Enrichment day: Tuesday 9 AM–noon (tweakable prop).
- `Bible Story Sheets.dc.html` — 8 pages: Creation, Noah, Jonah, Lost Sheep × (Big Kid / Little Sister).
- `*.dc-print.html` — print-stamped copies used for the PDF exports; regenerate rather than edit.
- `doc-page.js`, `support.js` — runtime shells the pages load. Keep alongside the HTML.

## Design decisions
- Font: Andika (SIL) for all traceable glyphs; Caprasimo display + Figtree body (Organic design system palette: terracotta #c67139, sage #7a8a5e, cream ground).
- Start dots: sage dots only (no arrows), positioned per-letter via lookup tables in each file's logic class — coordinates are fractions of font size, tune there.
- All art is inline SVG line art with white colorable interiors; grayscale-safe.

## Suggested repo layout
Commit exported PDFs to `materials/` (e.g. `materials/big-kid-tracing-pages-A-Z.pdf`, `toddler-letter-pages-A-Z.pdf`, `weekly-rhythm-chart.pdf`, `bible-story-sheets.pdf`). The HTML here can live in `materials/design/` as source of truth; `generate_printables.py` is superseded.

## Regenerating PDFs
Open any `.dc.html` in a browser and print to PDF (letter; rhythm chart is landscape). Tweakable props (letter subset, hunt scene, giant-letter case, enrichment day/hours) are set via the host's Tweaks panel or `data-props` defaults in the file.
